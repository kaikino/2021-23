import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Ask the user for the subject
        System.out.print("Enter the subject (Chemistry, Math, or English): ");
        String subject = sc.nextLine();

        // Set the test score and weight variables based on the subject
        double score1 = 0, score2 = 0, score3 = 0, iaScore = 0;
        double weight1 = 0, weight2 = 0, weight3 = 0, iaWeight = 0;
        switch (subject) {
            case "Chemistry":
                score1 = 0; weight1 = 0.2;
                score2 = 0; weight2 = 0.4;
                score3 = 0; weight3 = 0.2;
                iaScore = 0; iaWeight = 0.2;
                System.out.println("Enter scores for Chemistry Paper 1 (out of 30):");
                score1 = sc.nextDouble();
                System.out.println("Enter scores for Chemistry Paper 2 (out of 50):");
                score2 = sc.nextDouble();
                System.out.println("Enter scores for Chemistry Paper 3 (out of 35):");
                score3 = sc.nextDouble();
                System.out.println("Enter scores for Chemistry IA (out of 24):");
                iaScore = sc.nextDouble();
                break;
            case "Math":
                score1 = 0; weight1 = 0.3;
                score2 = 0; weight2 = 0.3;
                score3 = 0; weight3 = 0.2;
                iaScore = 0; iaWeight = 0.2;
                System.out.println("Enter scores for Math Paper 1 (out of 110):");
                score1 = sc.nextDouble();
                System.out.println("Enter scores for Math Paper 2 (out of 110):");
                score2 = sc.nextDouble();
                System.out.println("Enter scores for Math Paper 3 (out of 55):");
                score3 = sc.nextDouble();
                System.out.println("Enter scores for Math IA (out of 20):");
                iaScore = sc.nextDouble();
                break;
            case "English":
                score1 = 0; weight1 = 0.35;
                score2 = 0; weight2 = 0.25;
                double essayScore = 0; double essayWeight = 0.2;
                iaScore = 0; iaWeight = 0.2;
                System.out.println("Enter scores for English Paper 1 (out of 40):");
                score1 = sc.nextDouble();
                System.out.println("Enter scores for English Paper 2 (out of 30):");
                score2 = sc.nextDouble();
                System.out.println("Enter scores for English HL Essay (out of 20):");
                essayScore = sc.nextDouble();
                System.out.println("Enter scores for English IA (out of 40):");
                iaScore = sc.nextDouble();
                break;
            default:
                System.out.println("Invalid subject choice!");
                return;
        }
      double score= score1*weight1+score2*weight2;
      System.out.println("Your percentage score is "+score);
    }
}