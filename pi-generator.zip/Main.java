import java.math.BigDecimal;
import java.math.MathContext;

public class Main {

    public static void main(String[] args) {
        int digits = 100; // number of digits of pi to calculate
        BigDecimal pi = calculatePi(digits);
        System.out.println(pi);
    }

    public static BigDecimal calculatePi(int digits) {
        MathContext mc = new MathContext(digits + 1);
        BigDecimal pi = BigDecimal.ZERO;
        for (int k = 0; k < digits; k++) {
            BigDecimal term1 = BigDecimal.valueOf(4).divide(BigDecimal.valueOf(8 * k + 1), mc);
            BigDecimal term2 = BigDecimal.valueOf(2).divide(BigDecimal.valueOf(8 * k + 4), mc);
            BigDecimal term3 = BigDecimal.valueOf(1).divide(BigDecimal.valueOf(8 * k + 5), mc);
            BigDecimal term4 = BigDecimal.valueOf(1).divide(BigDecimal.valueOf(8 * k + 6), mc);
            BigDecimal term = term1.subtract(term2, mc).subtract(term3, mc).subtract(term4, mc);
            BigDecimal power = BigDecimal.valueOf(16).pow(-k, mc);
            pi = pi.add(term.multiply(power, mc), mc);
        }
        return pi;
    }
}
